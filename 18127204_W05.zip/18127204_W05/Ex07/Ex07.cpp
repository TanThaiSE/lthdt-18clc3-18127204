#include"DynamicArray.h"
#include"Tokenizer.h"
int main()
{
	DynamicArray d;
	cin >> d;
	cout << d.Tostring();
	DynamicArray e;
	e.parse();
	
	return 0;
}